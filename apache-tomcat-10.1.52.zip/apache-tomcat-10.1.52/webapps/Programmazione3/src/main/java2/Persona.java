public interface Persona {
    void apriDocumento();
}