public class Utente implements Persona {
    @Override
    public void apriDocumento() {
        System.out.println("Benvenuto utente! Qui puoi usare le funzionalità da utente.");
        // qui aggiungi il menu o la UI utente
    }
}