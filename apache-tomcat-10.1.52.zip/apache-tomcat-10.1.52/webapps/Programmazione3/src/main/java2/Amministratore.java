public class Amministratore implements Persona {
    @Override
    public void apriDocumento() {
        System.out.println("Benvenuto amministratore! Qui puoi usare le funzionalità admin.");
        // qui aggiungi il menu o la UI admin
    }
}